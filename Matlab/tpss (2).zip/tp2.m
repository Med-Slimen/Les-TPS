a=[1 2; 3 4]
element=a(1,2);
a(2,1)=5;
b=[5 6;7 8];
c=a*b;
d=a';
y=sum(a,"all");



