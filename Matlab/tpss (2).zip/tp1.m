a=1;
b=9;
c=a+b;
d=cos(a);
sin(b)
e=a*b;


